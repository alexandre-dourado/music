// ============================================================
// PRIVATE MUSIC FEEDBACK PLATFORM — Code.gs
// Google Apps Script Backend
// ============================================================

// ── CONFIGURATION ────────────────────────────────────────────
const CONFIG = {
  SPREADSHEET_ID: 'YOUR_SPREADSHEET_ID_HERE',   // ← replace
  SHEET_MUSICAS: 'musicas',
  SHEET_FEEDBACK: 'feedback',
  DRIVE_FOLDER_AUDIOS: 'YOUR_AUDIOS_FOLDER_ID',  // ← replace
  DRIVE_FOLDER_LETRAS: 'YOUR_LETRAS_FOLDER_ID',  // ← replace
  DRIVE_FOLDER_CAPAS: 'YOUR_CAPAS_FOLDER_ID',    // ← replace
  CACHE_TTL: 300, // 5 minutes
};

// ── ENTRY POINT ──────────────────────────────────────────────

/**
 * Serve the web application.
 */
function doGet(e) {
  const page = e.parameter.page || 'gallery';
  const musicId = e.parameter.id || '';

  const tmpl = HtmlService.createTemplateFromFile('index');
  tmpl.page = page;
  tmpl.musicId = musicId;

  return tmpl
    .evaluate()
    .setTitle('🎵 Ouça Agora')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/**
 * Include helper — lets index.html use <?!= include('file') ?>
 */
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

// ── SPREADSHEET HELPERS ──────────────────────────────────────

function getSpreadsheet() {
  return SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
}

function getSheet(name) {
  return getSpreadsheet().getSheetByName(name);
}

/**
 * Return sheet rows as array of plain objects keyed by header row.
 */
function sheetToObjects(sheet) {
  const [headers, ...rows] = sheet.getDataRange().getValues();
  return rows.map(row => {
    const obj = {};
    headers.forEach((h, i) => { obj[h] = row[i]; });
    return obj;
  });
}

// ── PUBLIC API ───────────────────────────────────────────────

/**
 * Returns the published music list (publicar === true), ordered by ordem.
 * Cached for CONFIG.CACHE_TTL seconds.
 */
function getMusicas() {
  const cache = CacheService.getScriptCache();
  const cached = cache.get('musicas_list');
  if (cached) return JSON.parse(cached);

  const sheet = getSheet(CONFIG.SHEET_MUSICAS);
  const all = sheetToObjects(sheet);
  const published = all
    .filter(m => m.publicar === true || m.publicar === 'TRUE')
    .sort((a, b) => Number(a.ordem) - Number(b.ordem))
    .map(m => sanitizeMusica(m));

  // Attach aggregated feedback
  const feedbackMap = getFeedbackAggregated();
  published.forEach(m => {
    m.feedback = feedbackMap[m.id] || { media_nota: null, total_notas: 0, reacoes: {} };
  });

  const result = JSON.stringify(published);
  cache.put('musicas_list', result, CONFIG.CACHE_TTL);
  return JSON.parse(result);
}

/**
 * Returns a single music entry by id.
 */
function getMusica(id) {
  const all = getMusicas();
  return all.find(m => String(m.id) === String(id)) || null;
}

/**
 * Returns lyrics text from Drive for a given letra_id.
 * Cached per file.
 */
function getLyrics(letraId) {
  if (!letraId) return '';

  const cache = CacheService.getScriptCache();
  const key = 'letra_' + letraId;
  const cached = cache.get(key);
  if (cached) return cached;

  try {
    const file = DriveApp.getFileById(letraId);
    const text = file.getBlob().getDataAsString('UTF-8');
    cache.put(key, text, CONFIG.CACHE_TTL * 6); // lyrics rarely change
    return text;
  } catch (e) {
    Logger.log('getLyrics error: ' + e.message);
    return '';
  }
}

/**
 * Returns a signed streaming URL for an audio file.
 * We expose the Drive preview URL which works in <audio>.
 */
function getAudioUrl(audioId) {
  if (!audioId) return null;
  // Direct download link — works for audio streaming
  return `https://drive.google.com/uc?export=download&id=${audioId}`;
}

/**
 * Returns a cover image URL for a given capa_id.
 */
function getCoverUrl(capaId) {
  if (!capaId) return null;
  return `https://drive.google.com/thumbnail?id=${capaId}&sz=w400`;
}

// ── FEEDBACK ─────────────────────────────────────────────────

/**
 * Submit feedback from a listener.
 * @param {Object} payload - { musica_id, nota, reacao, comentario, user_hash }
 */
function submitFeedback(payload) {
  // Validate
  const { musica_id, nota, reacao, comentario, user_hash } = payload;

  if (!musica_id) throw new Error('musica_id is required');
  if (nota !== null && nota !== undefined && (isNaN(nota) || nota < 1 || nota > 5)) {
    throw new Error('nota must be between 1 and 5');
  }
  const allowedReacoes = ['👍', '🔥', '💭', ''];
  if (reacao && !allowedReacoes.includes(reacao)) {
    throw new Error('Invalid reaction');
  }

  // Sanitize comment — strip HTML
  const safeComentario = String(comentario || '').replace(/<[^>]*>/g, '').substring(0, 1000);

  const sheet = getSheet(CONFIG.SHEET_FEEDBACK);
  sheet.appendRow([
    new Date(),
    String(musica_id),
    nota !== null && nota !== undefined ? Number(nota) : '',
    reacao || '',
    safeComentario,
    String(user_hash || ''),
  ]);

  // Invalidate cache
  CacheService.getScriptCache().remove('musicas_list');
  CacheService.getScriptCache().remove('feedback_agg');

  return { success: true };
}

/**
 * Returns aggregated feedback by musica_id.
 * { musica_id: { media_nota, total_notas, reacoes: { '👍': N, ... } } }
 */
function getFeedbackAggregated() {
  const cache = CacheService.getScriptCache();
  const cached = cache.get('feedback_agg');
  if (cached) return JSON.parse(cached);

  const sheet = getSheet(CONFIG.SHEET_FEEDBACK);
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return {};

  const data = sheet.getRange(2, 1, lastRow - 1, 6).getValues();
  // cols: timestamp, musica_id, nota, reacao, comentario, user_hash

  const map = {};
  data.forEach(row => {
    const id = String(row[1]);
    const nota = row[2];
    const reacao = row[3];
    if (!map[id]) map[id] = { notas: [], reacoes: {} };
    if (nota !== '' && !isNaN(nota)) map[id].notas.push(Number(nota));
    if (reacao) map[id].reacoes[reacao] = (map[id].reacoes[reacao] || 0) + 1;
  });

  const result = {};
  Object.keys(map).forEach(id => {
    const { notas, reacoes } = map[id];
    const media = notas.length ? (notas.reduce((a, b) => a + b, 0) / notas.length) : null;
    result[id] = {
      media_nota: media ? Math.round(media * 10) / 10 : null,
      total_notas: notas.length,
      reacoes,
    };
  });

  cache.put('feedback_agg', JSON.stringify(result), CONFIG.CACHE_TTL);
  return result;
}

// ── SETUP UTILITIES ──────────────────────────────────────────

/**
 * One-time setup: create sheets with correct headers if they don't exist.
 * Run this manually from the Apps Script editor once.
 */
function setupSheets() {
  const ss = getSpreadsheet();

  // musicas sheet
  let musicas = ss.getSheetByName(CONFIG.SHEET_MUSICAS);
  if (!musicas) {
    musicas = ss.insertSheet(CONFIG.SHEET_MUSICAS);
    musicas.appendRow(['id','titulo','audio_id','letra_id','capa_id','notas_autor','publicar','ordem','data_publicacao']);
    musicas.getRange(1, 1, 1, 9).setFontWeight('bold').setBackground('#1a1a2e').setFontColor('#ffffff');
    Logger.log('Sheet "musicas" created.');
  }

  // feedback sheet
  let feedback = ss.getSheetByName(CONFIG.SHEET_FEEDBACK);
  if (!feedback) {
    feedback = ss.insertSheet(CONFIG.SHEET_FEEDBACK);
    feedback.appendRow(['timestamp','musica_id','nota','reacao','comentario','user_hash']);
    feedback.getRange(1, 1, 1, 6).setFontWeight('bold').setBackground('#1a1a2e').setFontColor('#ffffff');
    Logger.log('Sheet "feedback" created.');
  }

  Logger.log('Setup complete.');
}

// ── PRIVATE HELPERS ──────────────────────────────────────────

/**
 * Strip sensitive fields before sending to frontend.
 * Comments are NEVER exposed.
 */
function sanitizeMusica(m) {
  return {
    id: m.id,
    titulo: m.titulo,
    audio_id: m.audio_id,
    letra_id: m.letra_id,
    capa_id: m.capa_id,
    notas_autor: m.notas_autor,
    ordem: m.ordem,
    data_publicacao: m.data_publicacao ? String(m.data_publicacao) : '',
    // publicar and internal fields intentionally omitted
  };
}
